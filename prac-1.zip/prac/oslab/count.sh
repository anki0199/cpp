#!/bin/bash
COUNT=5
echo "count=$COUNT"
#comment
echo We have $COUNT oranges

#SECOND PROGRAM
MESSAGE=Hello
echo "I want to say: $MESSAGE"

#bekow two lines does not work because of space between hello and there it can work with quotation
# MESSAGE1=Hello there
# echo "I want to say: $MESSAGE1"

MESSAGE2="Hello there"
echo "I want to say:$MESSAGE2"
