#!/bin/bash
a=10
b=5

if [ $a -eq $b ]
then
echo "they are equal"
fi
if [ $a -ne $b ]
then
echo "they are not equal"
fi
