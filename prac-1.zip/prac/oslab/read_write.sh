#!/bin/bash
# read name age city
# echo "My name is:  $name"
# echo "My age is: $age"
# echo "My city is: $city"

echo -n "Enter your age:"
read AGE
echo "Your age is $AGE"

read -p "enter your name:" NAME
echo $NAME
