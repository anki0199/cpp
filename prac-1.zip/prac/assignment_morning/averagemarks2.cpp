#include<iostream>
using namespace std;
int main(){
	int a,b,c,d,e;
	float avg;
	
	cout<<"enter the marks of five subjects\n";
	cin>>a>>b>>c>>d>>e;
	
	avg=(a+b+c+d+e)/5.0;
	
	cout<<"the average is:"<<avg;
	
	
	
	
	return 0;
}
