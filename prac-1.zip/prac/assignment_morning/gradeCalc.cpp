#include<iostream>
using namespace std;

int main(){
int count;

do{
	cout<<"enter data of student "<<count;
}

return 0;
}

