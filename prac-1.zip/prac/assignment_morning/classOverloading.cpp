#include<iostream>
using namespace std;

class BigInt{
int num;
	public:
	

int main(){
	
	
	return 0;
}

