#include<iostream>
using namespace std;

int main(){
	char c;	
	cout<<"Enter a character\n";

	cin>>c;
	
	cout<<"The ascii value of "<<c<<" is "<<(int)c;
	
	return 0;
}
